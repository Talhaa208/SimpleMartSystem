﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MartsysystemOPP.AUD.Factory
{
   public interface igetcategory
    {
        void cat_showpro(DataGridView dgv);
        
    }
}
